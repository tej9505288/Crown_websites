(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner(0);
    
    
    // Initiate the wowjs
    new WOW().init();


    // Fixed Navbar
    $(window).scroll(function () {
        if ($(window).width() < 992) {
            if ($(this).scrollTop() > 45) {
                $('.fixed-top').addClass('bg-white shadow');
            } else {
                $('.fixed-top').removeClass('bg-white shadow');
            }
        } else {
            if ($(this).scrollTop() > 45) {
                $('.fixed-top').addClass('bg-white shadow').css('top', -45);
            } else {
                $('.fixed-top').removeClass('bg-white shadow').css('top', 0);
            }
        }
    });
    
    
   // Back to top button
   $(window).scroll(function () {
    if ($(this).scrollTop() > 300) {
        $('.back-to-top').fadeIn('slow');
    } else {
        $('.back-to-top').fadeOut('slow');
    }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Testimonial carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1500,
        dots: false,
        loop: true,
        margin: 25,
        nav : true,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsive: {
            0:{
                items:1
            },
            768:{
                items:1
            },
            992:{
                items:2
            },
            1200:{
                items:3
            }
        }
    });

})(jQuery);

let currentImageIndex = 0;
const images = [
  'img/gallery-1.jpg',
  'img/gallery-2.jpg',
  'img/gallery-3.jpg',
  'img/gallery-4.jpg',
  'img/gallery-5.jpg',
  'img/gallery-6.jpg',
  'img/gallery-7.jpg',
  'img/gallery-8.jpg',
  'img/gallery-9.jpeg',
  'img/gallery-10.jpeg',
  'img/gallery-11.jpg',
  'img/gallery-12.jpg',
  'img/gallery-13.jpg',
  'img/gallery-14.jpg',
  'img/gallery-15.jpg',
  'img/gallery-16.jpg',
  'img/gallery-17.jpg',
  'img/gallery-18.jpg',
  'img/gallery-19.jpg',
  'img/gallery-20.jpg',
  'img/gallery-21.jpg',
  'img/gallery-22.jpg',
  'img/gallery-23.jpg',
  'img/gallery-24.jpg',
  'img/gallery-25.jpg',
  'img/gallery-26.jpg',
  'img/gallery-27.jpg',
  'img/gallery-28.jpg',
  'img/gallery-29.jpg',
  'img/gallery-30.jpg',
  'img/gallery-31.jpg',
  'img/gallery-32.jpg',
  'img/gallery-33.jpg',
  'img/gallery-34.jpg',
  'img/gallery-35.jpg',
  'img/gallery-36.jpg',
  'img/gallery-37.jpg',
  'img/gallery-38.jpg',
  'img/gallery-39.jpg',
  'img/gallery-40.jpg',
  'img/gallery-41.jpg',
  'img/gallery-42.jpg',
  'img/gallery-43.jpg',
  'img/gallery-44.jpg',
  'img/gallery-45.jpg',
  'img/gallery-46.jpg',
  'img/gallery-47.jpg',
  'img/gallery-48.jpg',
  'img/gallery-49.jpg',
  'img/gallery-50.jpeg',
  'img/gallery-51.jpeg',
  'img/gallery-52.jpg',
  'img/gallery-53.jpg',
  'img/gallery-54.jpg',
  'img/gallery-55.jpg',
  'img/gallery-56.jpg',
  'img/gallery-57.jpg',
  'img/gallery-58.jpg',
  'img/gallery-59.jpg',
  'img/gallery-60.jpg',
  'img/gallery-61.jpeg',
  'img/gallery-62.jpeg',
  'img/gallery-63.jpeg',
  'img/gallery-64.jpeg',
  'img/gallery-65.jpg',
  'img/gallery-66.jpg',
  'img/gallery-67.jpg',
  'img/gallery-68.jpg',
  'img/gallery-69.jpg',
  'img/gallery-70.jpg',
  'img/gallery-71.jpg',
  'img/gallery-72.jpg',
  'img/gallery-73.jpg',
  'img/gallery-74.jpg',
  'img/gallery-75.jpg',
  // Add more image paths if needed
];

// Open the modal and display the clicked image
function openModal(index) {
    currentImageIndex = index;
    const modalImage = document.getElementById('modalImage');
    modalImage.src = images[currentImageIndex];
    document.getElementById('imageModal').style.display = 'flex';
  }
  
  // Close the modal
  function closeModal() {
    document.getElementById('imageModal').style.display = 'none';
  }
  
  // Change image based on navigation
  function changeImage(direction) {
    currentImageIndex = (currentImageIndex + direction + images.length) % images.length;
    const modalImage = document.getElementById('modalImage');
    modalImage.src = images[currentImageIndex];
  }